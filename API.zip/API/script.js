document.getElementById("FishSubmit").addEventListener("click", function(event) {
  event.preventDefault();
  const value = document.getElementById("FishInput").value;
  if (value === "")
    return;
  console.log(value);

  const url = "https://www.fishwatch.gov/api/species?q=" + value;
  fetch(url)
    .then(function(response) {
      return response.json();
    }).then(function(json) {	
        let results = "";
        let index = -1;
        for (let i = 0; i < json.length; i++) {
          if (value === json[i]["Species Name"]) {
            index = i;
            console.log("yay");
          }
        }
        results += '<h2>Name: ' + json[index]["Species Name"] + "</h2>";
        results += "<p> Scientific Name: " +  json[index]["Scientific Name"] + "</p>";
        results += "<p> Population: " +  json[index]["Population Status"] + "</p>";
        results += "<p> Habitat: " +  json[index]["Habitat"] + "</p>";
        results += "<p> Location: " +  json[index]["Location"] + "</p>";
        results += "<p> Description: " +  json[index]["Physical Description"] + "</p>";
        

        
        console.log(index);
        console.log(json[index]);
      document.getElementById("fishResults").innerHTML = results;
    });
});
